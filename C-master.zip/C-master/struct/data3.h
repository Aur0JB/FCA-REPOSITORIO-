struct biblioteca { // Crea la estructura del registro
	char codigo[10];
	char titulo[50];
	char autor[50];
}libro2;