struct biblioteca { // Crea la estructura del registro
	int code;
	char titulo[20];
	char autor[20];
}libro;
