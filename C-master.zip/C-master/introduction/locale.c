#include <stdio.h>
#include <locale.h>
int main(){
 setlocale(LC_CTYPE,"Spanish");
 printf("Niños");
 return 0;
}
