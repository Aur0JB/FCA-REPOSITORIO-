#include <stdio.h>
#include <stdlib.h>

int main(){
 
 printf("ni%cos \n",164);//ñ
 printf("ni%cos",165);//Ñ 
 return 0;
}
