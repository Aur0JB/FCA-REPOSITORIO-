#include<stdio.h>
#include<math.h>
#define PI 3.1416

int main(){
	float area, radio;
	radio = 5;
	area = PI * pow(5,2);
	printf("Area\n");
	printf("%s%f\n\n", "Area de Circulo con radio 5:", area);
}
