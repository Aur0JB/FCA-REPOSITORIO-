#include <stdio.h> // Archivo de cabecera para subrutinas de e/s
#include <stdlib.h> // Archivo de cabecera para subrutinas de utilidades
int a = 2;
int b = 4;
float c;
int main()
{ // Inicio
 c=(float)a+b;
 system("clear"); // Limpia pantallpa
 printf("C vale %f\n",c); 
 return 0;
} // Fin de programa
