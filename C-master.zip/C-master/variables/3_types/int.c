#include <stdio.h>
int letra; // Carácter de una posición
int main()
{
int system(const char clear);
letra='6'; // Asigna valor
printf("La numero %d en ASCII es %c\n",letra,letra);
return 0;
} 
