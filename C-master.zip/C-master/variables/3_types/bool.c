#include<stdio.h>
#include<stdbool.h>// Boolean
 
int main(){
    bool reprobado = false;
    if(reprobado){
        printf("Reprobaste el taller\n");
    }else{
        printf("Aprobaste con 6\n");
    }
}
