#include <stdlib.h>
#include <stdio.h>

#define STOP 'S'
int main()
{
char ch;
while ((ch =getchar())!=STOP){
	putchar(ch);
} 
} 
